<!--getting layout from layout/app.php -->
@extends('layouts.app')


<!--wrapping content to appear in main content -->
@section('content')
        <h1>My first Laravel Site</h1>
@endsection