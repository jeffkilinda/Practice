@extends('layouts.app')



@section('content')
    
<div class="pages-div">

    
<h2>Disclaimer</h2>

<p>These are only predictions and We don't guarantee 100% accuracy of the predictions. Our tips are meant to give guidance
to bet wisely. It doesn’t mean what we predict may always come out 
correct but we quarantee very high accuracy of the tips we give. Therefore we advise our users to do some analysis of their own before 
settling to our predictions.</p>


<p>Superbet bet bet  Predictions is not a bookie hence doesn't collect money from users. Superbet bet bet  Predictions website is built as as an Ad Supported website. 
This SERVICE is provided by Superbet bet bet  predictions at no cost and is intended for use as it is.</p>

 <p>
Superbet bet bet predictions believes in betting as a form of pure entertainment and guarantees its customers a pleasant recreational
 experience while remaining aware of the social and financial problems related to betting. 
 Our tips and predictions are guidance and must not be considered as incitement to gambling.
 We advise our users that gambling should be regarded as entertainment and not solutions to financial problems. 
 Users who uses our site for gambling are responsible for their actions and there is no way we shall accountable for any loss of money 
 or anything else that may result from the use of the information on this website.</p>

<p>These Terms shall be governed and construed in accordance with the laws in your 
jurisdiction, without regard to its conflict of law provisions. Do not use our service for any illegal purpose.Please leave Superbet bet bet Predictions 
immediately if your country prohibits online gambling, as we are not responsible for any legal matters arising from using our services</p>


</div>
@endsection


