@extends('layouts.app')



@section('content')
    <div class="pages-div">

        
<h2>SuperbetPredictions</h2>

<p>SuperPredictions is all about Football statistics, match predictions, bet tips, expert reviews and bet information. 
We cover all the major football events across Europe and the world. 
We do thorough match analysis and give our users great and safe bet tips
to gamble safely and resposibly</p>

 <p>Accuracy, reliability and Simplicity are our main goals so you can
      relly on us for well analysed predictions and tips to help you 
      make real 
money in gambling</p>

<p>Superbet bet bet Predictions works with the qualified and expert analysers in 
    the world to guarantee sure betting tips.
Every day, hundredss of users come back to our site thanking us for real winnings through our tips. </p>



<p>These are only predictions and We don't guarantee 100% accuracy of 
    the predictions. It doesn’t mean what we predict may always  come 
    out correct but we quarantee 90% accuracy of the tips we give.
Therefore we advise our users to do some analysis of their own before settling to our predictions.</p>

    </div>
  
@endsection


