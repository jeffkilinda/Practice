@extends('layouts.app')



@section('content')

<h1 style="text-align:center">Top Tips </h1>
    
@include('inc.tipstable')

@endsection

