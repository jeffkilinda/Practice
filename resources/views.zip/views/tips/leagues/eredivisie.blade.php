@extends('layouts.app')



@section('content')

<h1 style="text-align:center">Today Eredivisie Tips </h1>
    
@include('inc.tipstable')

@endsection

