@extends('layouts.app')



@section('content')
    


<h1 style="text-align:center">Previous Winnings </h1>
    
@include('inc.tipstable')

@endsection

